package vehiculaire.upem.fr.securityvehiculaire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Toast;

public class Passager extends AppCompatActivity implements InterfacePersonne{

    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passager);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Espace Passager");
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(Passager.this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //menu of passager when we can choose the event
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_send_via_wifi:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new SendMessageViaWifi()).commit();
                break;

            case R.id.nav_send_via_bluetooth:
                Intent ble = new Intent(this, SendMessageViaBluetooth.class);
                startActivity(ble);
                break;

            case R.id.nav_hotel:
                Intent hotel = new Intent(this, GoogleMapsActivity.class);
                startActivity(hotel);
                break;

            case R.id.nav_logout:
                Intent logout = new Intent(this, Authentification.class);
                Toast.makeText(this, "Bien déconnecter", Toast.LENGTH_SHORT).show();
                startActivity(logout);
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
