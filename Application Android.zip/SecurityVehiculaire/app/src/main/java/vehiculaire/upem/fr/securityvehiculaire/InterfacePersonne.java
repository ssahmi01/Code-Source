package vehiculaire.upem.fr.securityvehiculaire;

import android.support.design.widget.NavigationView;

public interface InterfacePersonne extends NavigationView.OnNavigationItemSelectedListener {


}
