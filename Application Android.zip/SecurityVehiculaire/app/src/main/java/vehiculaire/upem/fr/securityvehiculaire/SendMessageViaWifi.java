package vehiculaire.upem.fr.securityvehiculaire;

import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class SendMessageViaWifi extends Fragment {
    EditText editTextAddress, editTextPort, editTextMsg;
    Button buttonConnect;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((Conducteur)getActivity()).setActionBarTitle("Envoyer un message");
        View v= inflater.inflate(R.layout.activity_send_message_via_wifi, container, false);
        editTextAddress = (EditText) v.findViewById(R.id.address);
        editTextPort = (EditText) v.findViewById(R.id.port);
        editTextMsg = (EditText) v.findViewById(R.id.msgtosend);
        buttonConnect = (Button) v.findViewById(R.id.connect);
        buttonConnect.setOnClickListener(buttonConnectOnClickListener);
        return v;
    }
    View.OnClickListener buttonConnectOnClickListener =
            new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    //Using MyClientTask in order to communicate with Raspberry
                    MyClientTask myClientTask = new MyClientTask(
                            editTextAddress.getText().toString(),
                            Integer.parseInt(editTextPort.getText().toString()));
                    //execute : call method doInBackGround()
                    myClientTask.execute(editTextMsg.getText().toString());
                }
            };

//using class static in SendMessageViaWifi
    public static class MyClientTask extends AsyncTask<String, Void, Void> {
        String dstAddress;
        int dstPort;
        String response;
        MyClientTask(String addr, int port) {
            dstAddress = addr;
            dstPort = port;
            response ="";
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected void onCancelled() {
            super.onCancelled();
            this.cancel(true);
        }

        @Override
        protected Void doInBackground(String... params) {
            try {
                    //Send message to Raspberry
                    Socket socket = new Socket(dstAddress, dstPort);
                    Log.i(dstAddress, "" + dstPort);
                    OutputStream outputStream = socket.getOutputStream();
                    PrintStream printStream = new PrintStream(outputStream);
                    printStream.print(params[0]+"\n");

                    //Receive message from Raspberry
                    InputStream inputStream = socket.getInputStream();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    Log.i("respense", "debut");
                    String line;
                    while(((line = bufferedReader.readLine()) != null)){
                        System.out.println(line);
                        response = line;
                        //if(isCancelled()) break;
                    }
                    System.out.println(response);
                socket.close();
            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return null;
            }
            return null;
        }
    }
}
