package vehiculaire.upem.fr.securityvehiculaire;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.HashMap;

public class Authentification extends AppCompatActivity {
    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button login;
    private int counter = 5;
    private TextView error;
    private HashMap<String, InterfacePersonne> map = new HashMap<>();

    public Authentification() {
        //assign the class according to user
        map.put("conducteur", new Conducteur());
        map.put("passager", new Passager());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentification);
        Name = (EditText)findViewById(R.id.etName);
        Password = (EditText)findViewById(R.id.etPassword);
        Info = (TextView)findViewById(R.id.tvInfo);
        login = (Button)findViewById(R.id.btnLogin);
        error = (TextView) findViewById(R.id.error);
        Info.setText("No of attempts remaining: 5");
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //call this methode in order to communicate with our Raspberry using @ip, port, name and pwd
                validate("172.20.10.7",8000, Name.getText().toString(), Password.getText().toString());
            }
        });
    }

    private void validate(String addr, int port, String user, String pwd) {
        //call the class SendMessageViaWifi in order to use the function doInBackGround
        SendMessageViaWifi.MyClientTask mct= new SendMessageViaWifi.MyClientTask(addr, port);
        mct.execute(user + " " + pwd);

        if(mct.response.equals("oui")){
            //Recover user then log in
            InterfacePersonne ip = map.get(user);
            if(ip != null){
                Intent intent = new Intent(this, ip.getClass());
                startActivity(intent);
            }else{
                counter--;
                error.setVisibility(View.VISIBLE);
                Info.setText("No of attempts remaining: " + String.valueOf(counter));
                if (counter == 0) {
                   login.setEnabled(false);
                }
            }
        }
    }
}
